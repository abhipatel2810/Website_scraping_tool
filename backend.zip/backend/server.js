import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';
import archiver from 'archiver';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 5001;
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || 'http://localhost:5173';

const PROJECT_ROOT = path.resolve(__dirname, process.env.PROJECT_ROOT || '..');
const SCRIPT_PATH = path.join(PROJECT_ROOT, 'site_dump.py');
const CRAWL_BASE = path.join(PROJECT_ROOT, 'crawl');
const PYTHON_EXE = process.env.PYTHON_EXE || 'python';

fs.mkdirSync(CRAWL_BASE, { recursive: true });

const app = express();
app.use(cors({ origin: CLIENT_ORIGIN }));
app.use(express.json({ limit: '1mb' }));

// Start crawl -> run site_dump.py -> zip result -> return link
app.post('/api/crawl', async (req, res) => {
  const {
    url,
    includeSubdomains = true,
    ignoreRobots = true,
    includePdfs = true,
    dataset = true,
    maxPages = 200,
    concurrency = 2,
    delayMs = 250,
    verbose = true,
    renderAll = false
  } = req.body || {};

  if (!url || !/^https?:\/\//i.test(url)) {
    return res.status(400).json({ error: 'invalid url' });
  }

  const jobId = new Date().toISOString().replace(/[:.TZ-]/g, '') + '-' + crypto.randomBytes(3).toString('hex');
  const outDir = path.join(CRAWL_BASE, jobId);
  fs.mkdirSync(outDir, { recursive: true });

  // Build args for your script
  const args = [
    SCRIPT_PATH,
    url,
    '--out-dir', outDir,
    '--max-pages', String(maxPages),
    '--concurrency', String(concurrency),
    '--delay-ms', String(delayMs),
    '--export-urls'
  ];
  if (includeSubdomains) args.push('--include-subdomains');
  if (ignoreRobots) args.push('--ignore-robots');
  if (includePdfs) args.push('--include-pdfs');
  if (dataset) args.push('--dataset');
  if (renderAll) args.push('--render-all');
  if (verbose) args.push('--verbose');

  const logPath = path.join(outDir, 'server-run.log');
  const logStream = fs.createWriteStream(logPath, { flags: 'a' });

  const child = spawn(PYTHON_EXE, args, {
    cwd: PROJECT_ROOT,
    env: process.env,
    shell: process.platform === 'win32' // helps PowerShell environments
  });

  child.stdout.on('data', (d) => logStream.write(d));
  child.stderr.on('data', (d) => logStream.write(d));

  child.on('close', async (code) => {
    logStream.end();

    if (code !== 0) {
      return res.status(500).json({
        status: 'error',
        jobId,
        outDirRel: path.relative(PROJECT_ROOT, outDir),
        logRel: path.relative(PROJECT_ROOT, logPath),
        message: `crawler exited with code ${code}`
      });
    }

    // Zip the outDir
    const zipPath = path.join(CRAWL_BASE, `${jobId}.zip`);
    try {
      await zipFolder(outDir, zipPath);
      return res.json({
        status: 'ok',
        jobId,
        outDirRel: path.relative(PROJECT_ROOT, outDir),
        zipRel: path.relative(PROJECT_ROOT, zipPath),
        downloadUrl: `/api/crawl/${jobId}/download`,
        logRel: path.relative(PROJECT_ROOT, logPath)
      });
    } catch (e) {
      return res.status(500).json({
        status: 'error',
        jobId,
        outDirRel: path.relative(PROJECT_ROOT, outDir),
        message: `zip failed: ${String(e)}`
      });
    }
  });
});
app.get('/', (_req, res) => res.type('text').send('API OK. POST /api/crawl'));

app.get('/api/crawl/:jobId/download', (req, res) => {
  const zipPath = path.join(CRAWL_BASE, `${req.params.jobId}.zip`);
  if (!fs.existsSync(zipPath)) return res.status(404).send('not found');
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="${req.params.jobId}.zip"`);
  fs.createReadStream(zipPath).pipe(res);
});

app.get('/api/crawl/:jobId/log', (req, res) => {
  const logPath = path.join(CRAWL_BASE, req.params.jobId, 'server-run.log');
  if (!fs.existsSync(logPath)) return res.status(404).send('not found');
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  fs.createReadStream(logPath).pipe(res);
});

app.listen(PORT, () => {
  console.log(`backend on http://localhost:${PORT}`);
});

// helpers
function zipFolder(srcFolder, destZip) {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(destZip);
    const archive = archiver('zip', { zlib: { level: 9 } });
    output.on('close', resolve);
    archive.on('error', reject);
    archive.pipe(output);
    archive.directory(srcFolder, false);
    archive.finalize();
  });
}
