param(
  [string]$remote = "origin",
  [string]$branch = "main",
  [string]$message = "chore: update"
)

git add -A
git commit -m $message
git push -u $remote $branch
