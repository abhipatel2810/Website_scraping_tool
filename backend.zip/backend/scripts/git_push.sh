#!/usr/bin/env bash
set -euo pipefail
remote="${1:-origin}"
branch="${2:-main}"
msg="${3:-chore: update}"
git add -A
git commit -m "$msg" || true
git push -u "$remote" "$branch"
