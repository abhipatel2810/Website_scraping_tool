import React, { useState } from 'react';


type CrawlResult = {
  status: string;
  jobId: string;
  outDirRel: string;
  zipRel?: string;
  downloadUrl?: string;
  logRel?: string;
  message?: string;
};

const API = 'http://localhost:5001';

export default function App() {
  const [url, setUrl] = useState('');
  const [includeSubdomains, setIncludeSubdomains] = useState(true);
  const [ignoreRobots, setIgnoreRobots] = useState(true);
  const [includePdfs, setIncludePdfs] = useState(true);
  const [dataset, setDataset] = useState(true);
  const [maxPages, setMaxPages] = useState(200);
  const [concurrency, setConcurrency] = useState(2);
  const [delayMs, setDelayMs] = useState(250);
  const [renderAll, setRenderAll] = useState(false);

  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<CrawlResult | null>(null);
  const [err, setErr] = useState<string | null>(null);

  async function runCrawl(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    setRes(null);

    try {
      const r = await fetch(`${API}/api/crawl`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          url,
          includeSubdomains,
          ignoreRobots,
          includePdfs,
          dataset,
          maxPages,
          concurrency,
          delayMs,
          renderAll,
          verbose: true
        })
      });
      const j = (await r.json()) as CrawlResult;
      if (!r.ok) throw new Error(j.message || 'crawl failed');
      setRes(j);
    } catch (e: any) {
      setErr(e.message || String(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen bg-white">
      <header className="border-b border-gray-100">
        <div className="max-w-5xl mx-auto px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/logo.png" alt="Veritas Scraper" className="h-9 object-cover"/>
          </div>
          <a className="text-primary underline" href="https://adaptable.pro" target="_blank">More Tools</a>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-10">
        <div className="grid md:grid-cols-3 gap-8">
          <form onSubmit={runCrawl} className="card md:col-span-2">
            <h2 className="text-lg font-semibold mb-4">New crawl</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm mb-1">Start URL</label>
                <input
                  className="input"
                  type="url"
                  required
                  placeholder="https://example.com"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <label className="inline-flex items-center gap-2">
                  <input type="checkbox" checked={includeSubdomains} onChange={(e) => setIncludeSubdomains(e.target.checked)} />
                  <span>Include subdomains</span>
                </label>
                <label className="inline-flex items-center gap-2">
                  <input type="checkbox" checked={ignoreRobots} onChange={(e) => setIgnoreRobots(e.target.checked)} />
                  <span>Ignore robots.txt</span>
                </label>
                <label className="inline-flex items-center gap-2">
                  <input type="checkbox" checked={includePdfs} onChange={(e) => setIncludePdfs(e.target.checked)} />
                  <span>Include PDFs</span>
                </label>
                <label className="inline-flex items-center gap-2">
                  <input type="checkbox" checked={dataset} onChange={(e) => setDataset(e.target.checked)} />
                  <span>Write dataset</span>
                </label>
                <label className="inline-flex items-center gap-2">
                  <input type="checkbox" checked={renderAll} onChange={(e) => setRenderAll(e.target.checked)} />
                  <span>Render JS</span>
                </label>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm mb-1">Max pages</label>
                  <input className="input" type="number" min={1} value={maxPages} onChange={(e) => setMaxPages(+e.target.value)} />
                </div>
                <div>
                  <label className="block text-sm mb-1">Concurrency</label>
                  <input className="input" type="number" min={1} value={concurrency} onChange={(e) => setConcurrency(+e.target.value)} />
                </div>
                <div>
                  <label className="block text-sm mb-1">Delay (ms)</label>
                  <input className="input" type="number" min={0} value={delayMs} onChange={(e) => setDelayMs(+e.target.value)} />
                </div>
              </div>

              <button className="btn" disabled={busy}>
                {busy ? 'Running…' : 'Run crawl'}
              </button>
            </div>
          </form>

          <div className="space-y-8">
            <div className="card">
              <h3 className="font-semibold mb-2">Status</h3>
              {err && <p className="text-red-600">{err}</p>}
              {!err && !res && <p className="text-gray-500">Idle</p>}
              {res && (
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium">Job:</span> {res.jobId}</p>
                  <p><span className="font-medium">Folder:</span> {res.outDirRel}</p>
                  {res.downloadUrl && (
                    <a
                      className="btn inline-block"
                      href={`http://localhost:5001${res.downloadUrl}`}
                    >
                      Download ZIP
                    </a>
                  )}
                  {res.logRel && (
                    <a
                      className="text-primary underline ml-3"
                      href={`http://localhost:5001/api/crawl/${res.jobId}/log`}
                      target="_blank"
                    >
                      View run log
                    </a>
                  )}
                </div>
              )}
            </div>

            <div className="card">
              <h3 className="font-semibold mb-2">Output layout</h3>
              <pre className="text-xs bg-gray-50 p-3 rounded-lg overflow-auto">
crawl/&lt;jobId&gt;/
  00001-*/page.html
  00001-*/page.json
  _assets/img/*
  _dataset/pages.jsonl
  _dataset/text.jsonl
  _dataset/links.jsonl
  graph.json
  index.jsonl
  crawl.log
              </pre>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
